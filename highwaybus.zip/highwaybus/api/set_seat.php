<?php
if(empty($_POST["s"]) || empty($_POST["ymd"])){
	exit();
}
require_once("../config.php");

$sql="UPDATE seats SET reserved = 1";
$sql .= " WHERE ymd=:ymd AND seat_id=:seat_id";
$stmt = $pdo->prepare($sql);//パン生地は1つでよろしい

//配列化
$sArr = explode(",",$_POST["s"]);
//echo($sArr);

foreach($sArr as $val){
	$stmt->bindValue(":ymd",$_POST["ymd"],PDO::PARAM_STR);
	$stmt->bindValue(":seat_id",$val,PDO::PARAM_INT);//いちおう悪さができないように
	$stmt->execute();
}

/*

$stmt->bindValue(":ymd",$_GET["ymd"],PDO::PARAM_STR);
$stmt->execute();

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

$json = json_encode($data);//api
echo $json;//こっそりみにいくがechoしてないと見れない
*/

?>
