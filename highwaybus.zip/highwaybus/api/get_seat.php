<?php
if(empty($_GET["ymd"])){
	exit();
}
require_once("../config.php");

$sql="SELECT * from seats WHERE ymd=:ymd";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(":ymd",$_GET["ymd"],PDO::PARAM_STR);
$stmt->execute();

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

$json = json_encode($data);//api
echo $json;//こっそりみにいくがechoしてないと見れない
?>
