<!DOCTYPE html>
<html lang="ja">
	<head>
		<meta charset="UTF-8">
		<title>座席予約</title>
		<link rel="stylesheet" href="css/style.css">
		<script src="../jquery-3.4.1.min.js"></script>
	</head>
	<body>
		<header>
			<h1>本日、明日、明後日のバスの予約</h1>
			<img src="car_bus.png">
		</header>
		
		<div id="container">
			<p>10：00発　大阪行き（1日1便）</p>
			<p>
				<select id="ymd">
					<option value="">日付の選択</option>
					<option value="2020-03-14">2020-03-14</option>
					<option value="2020-03-15">2020-03-15</option>
					<option value="2020-03-16">2020-03-16</option>
				</select>
			</p>
			
			<div id="front">進行方向↑</div>
			<div id="bus">
			</div>
			<p id="end"><button id="b1">決定</button></p>
		</div>

		<script src="js/seat.js"></script>		
	</body>
</html>

