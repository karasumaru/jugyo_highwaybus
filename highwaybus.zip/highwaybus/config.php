<?php
//setting
//環境によって変える

//テスト環境用
$host = "localhost";
$dbname = "highwaybus";
$dbuser = "root";
$dbpass = "";

//本番環境用
/*
$host = "xxx";
$dbname = "highwaybus";
$dbuser = "xxx";
$dbpass = "xxx";
*/

//
$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8";
$pdo = new PDO($dsn,$dbuser,$dbpass);

/*
//定数を使うやり方
define("HOST_NAME","localhost");
define("DB_NAME","highwaybus");
define("DB_USER","root");
define("DB_PASS","");
echo HOST_NAME;
*/

?>
