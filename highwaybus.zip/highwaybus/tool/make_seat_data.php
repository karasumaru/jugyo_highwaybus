<?php
//?ymd=2020-03-14みたいにurlに追加すると出力

if(empty($_GET["ymd"])){
	exit();
}

require_once("../config.php");
$sql="INSERT INTO seats (ymd,seat_id,reserved)";
$sql.=" VALUES(:ymd,:seat_id,0)";
$stmt = $pdo->prepare($sql);

for($i=1; $i<=20; $i++){
	$stmt->bindValue(":ymd",$_GET["ymd"],PDO::PARAM_STR);
	$stmt->bindValue(":seat_id",$i,PDO::PARAM_INT);
	$stmt->execute();
}

?>

